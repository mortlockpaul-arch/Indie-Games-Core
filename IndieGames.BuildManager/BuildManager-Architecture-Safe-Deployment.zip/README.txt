Build Manager architecture-safe deployment patch

1. Back up existing MainWindow.xaml.cs.
2. Copy MainWindow.xaml.cs into IndieGames.BuildManager\MainWindow.xaml.cs.
3. Copy Services\GameOutputArchitecture.cs into IndieGames.BuildManager\Services\.
4. Rebuild and publish Build Manager, then rebuild the game with x64 selected.

When switching architectures, the old playable directory is MOVED to a timestamped backup beside it. Nothing is deleted. A successful build checks the primary EXE and DLL and records .buildmanager-architecture.

IMPORTANT: This patch uses the latest uploaded MainWindow.xaml.cs (2026-11-13 07:14), not later local edits. Merge if you changed it since. Windows build not tested here.
