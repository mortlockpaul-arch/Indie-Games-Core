using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;

namespace Renderer;

public static class SpriteManager
{
	public class DrawComponentComparer : IComparer<DrawableComponent>
	{
		public int Compare(DrawableComponent x, DrawableComponent y)
		{
			if (x.Depth > y.Depth)
			{
				return 1;
			}
			if (x.Depth == y.Depth)
			{
				return 0;
			}
			return -1;
		}
	}

	private const int MAX_TEXT = 2000;

	public static string SPECIAL_PAGE_NAME_GAMERPIC = "SPECIAL_PAGE_GAMERPIC";

	private static Dictionary<string, SpritePage> pages;

	private static GraphicsDevice device;

	private static ContentManager content;

	private static List<DrawableComponent> sm_drawList;

	private static DrawComponentComparer spriteComparer;

	private static List<RenderText> sm_textPool;

	private static int sm_iTextIndex;

	public static void Initialize(GraphicsDevice d, ContentManager c)
	{
		spriteComparer = new DrawComponentComparer();
		sm_drawList = new List<DrawableComponent>(10000);
		device = d;
		content = c;
		pages = new Dictionary<string, SpritePage>();
		sm_iTextIndex = 0;
		sm_textPool = new List<RenderText>(2000);
		for (int i = 0; i < 2000; i++)
		{
			sm_textPool.Add(new RenderText());
		}
	}

	public static RenderSprite GetSprite(string pageName, Vector2 pos, float depth)
	{
		return new RenderSprite(GetImage(pageName), pos, depth);
	}

	public static RenderSprite GetSprite(string pageName, Rectangle pageCoords, Vector2 pos, float depth)
	{
		return new RenderSprite(GetImage(pageName, pageCoords), pos, depth);
	}

	public static SpriteImage GetImage(string pageName, Rectangle pageCoords)
	{
		return new SpriteImage(GetPage(pageName), pageCoords);
	}

	public static SpriteImage GetImage(string pageName)
	{
		SpritePage page = GetPage(pageName);
		Rectangle coords = new Rectangle(0, 0, page.Texture.Width, page.Texture.Height);
		return new SpriteImage(page, coords);
	}

	public static void SetSpecialPage(Texture2D tex, string pageName)
	{
		pages[pageName] = new SpritePage(tex, pageName);
	}

	public static SpritePage GetPage(string pageName)
	{
		if (pageName.Equals(SPECIAL_PAGE_NAME_GAMERPIC))
		{
			PlayerIndex playerIndex = ControlManager.GetPlayerIndex(ControlManager.ActiveMenuIndex);
			SignedInGamer signedInGamer = null;
			foreach (SignedInGamer signedInGamer2 in Gamer.SignedInGamers)
			{
				if (signedInGamer2.PlayerIndex == playerIndex)
				{
					signedInGamer = signedInGamer2;
				}
			}
			if (signedInGamer != null)
			{
				GamerProfile profile = signedInGamer.GetProfile();
				Texture2D gamerPicture = content.Load<Texture2D>("blackzone");
				try
				{
					using (Stream pictureStream = profile.GetGamerPicture())
					{
						if (pictureStream != null && pictureStream.CanRead)
						{
							gamerPicture = Texture2D.FromStream(device, pictureStream);
						}
					}
				}
				catch (Exception)
				{
					// Offline NetStub profiles may have no decodable picture.
				}
				pages[pageName] = new SpritePage(gamerPicture, pageName);
			}
			else
			{
				pages[pageName] = new SpritePage(content.Load<Texture2D>("blackzone"), pageName);
			}
			return pages[pageName];
		}
		if (pages.ContainsKey(pageName))
		{
			return pages[pageName];
		}
		pages[pageName] = new SpritePage(content.Load<Texture2D>(pageName), pageName);
		return pages[pageName];
	}

	public static void Update(GameTime gameTime)
	{
	}

	public static void AddSpriteRefForDraw(RenderSprite s)
	{
		sm_drawList.Add(s);
	}

	public static void AddTextRefForDraw(SceneRenderer.textData t, float depth)
	{
		RenderText textRef = GetTextRef();
		textRef.Initialize(t, depth);
		sm_drawList.Add(textRef);
	}

	private static RenderText GetTextRef()
	{
		sm_iTextIndex++;
		return sm_textPool[Math.Min(2000, sm_iTextIndex) - 1];
	}

	public static void Draw(GameTime gameTime, bool canDrawAvatars)
	{
		Vector2 cameraPosition = SceneRenderer.GetCameraPosition() - SceneRenderer.GetViewportDim() / (SceneRenderer.GetCameraZoom() * 2f);
		sm_drawList.Sort(spriteComparer);
		AvatarHandler avatar = SceneRenderer.Avatar;
		bool flag = !canDrawAvatars;
		for (int i = 0; i < sm_drawList.Count; i++)
		{
			if (sm_drawList[i] is RenderSprite)
			{
				RenderSprite renderSprite = (RenderSprite)sm_drawList[i];
				bool blendAdditive = renderSprite.BlendAdditive;
				if (i > 0)
				{
					if (!(sm_drawList[i - 1] is RenderSprite) || ((RenderSprite)sm_drawList[i - 1]).BlendAdditive != blendAdditive)
					{
						SceneRenderer.SetBlendMode(blendAdditive);
					}
				}
				else
				{
					SceneRenderer.SetBlendMode(blendAdditive);
				}
				if (!flag && avatar != null && avatar.ShouldDraw && renderSprite.Depth > avatar.Depth)
				{
					SceneRenderer.ResetBatch();
					flag = true;
					avatar.Draw();
				}
				SceneRenderer.DrawRenderSpriteFromManager(renderSprite, inPass: false);
			}
			else
			{
				if (!flag && avatar != null && avatar.ShouldDraw && sm_drawList[i].Depth > avatar.Depth)
				{
					SceneRenderer.ResetBatch();
					flag = true;
					avatar.Draw();
				}
				SceneRenderer.DrawFinalString((RenderText)sm_drawList[i], cameraPosition);
			}
		}
		if (!flag && avatar != null && avatar.ShouldDraw)
		{
			SceneRenderer.ResetBatch();
			flag = true;
			avatar.Draw();
		}
		sm_drawList.Clear();
		sm_iTextIndex = 0;
	}
}
