Upstream XnaToFna v18.05.1, https://github.com/0x0ade/XnaToFna/releases/tag/v18.05.1
Original release ZIP SHA256: 8F97331CFDD02310CFEFBFFB6B29E96E9E50BB95261BFA29C61250AE9597C7D5
Upstream converter binaries are unmodified. Build Manager adds copy isolation, backups and reports.
The modified DLL from One Night You're Crazy is not bundled or used.
Source: https://github.com/0x0ade/XnaToFna; local fork https://github.com/mortlockpaul-arch/XnaToFna
