# XNA Content Reader Assembly Repair

This tool patches **uncompressed** XNB files whose reader table refers to the original `Renderer` assembly, for eight verified reader types in the `This Is Hard` game. It copies patched files to a separate output folder and does not alter original files.

## Commands (PowerShell)

```powershell
$tool = 'C:\path\to\XnaContentReaderRepair\Repair-XnaContentReaderAssemblies.ps1'
$root = 'D:\indie-game-archive\This Is Hard (World) (XBLIG)\Content'
& $tool -Root $root -WhatIf
& $tool -Root $root -Output 'D:\indie-game-archive\This Is Hard (World) (XBLIG)\Content-Patched'
```

Requires .NET 9 SDK. The output preserves relative asset paths. Inspect the output, then copy selected patched XNB files into the **runtime content output folder** after backing up the originals. `-WhatIf` scans without writing. The tool returns code 3 if compressed XNBs were skipped.

## Limitations

- Compressed XNB (LZX/LZ4) files are **reported and skipped**. Use XnbExtractor to inspect/decompress these, but an extractor that emits extracted objects is **not** a lossless XNB rebuilder. A codec-aware XNB decompression/recompression implementation is required to patch compressed files.
- Only eight exact reader type names are eligible; other reader references are unchanged.
- This is an assembly name migration, not a compatibility check for reader implementations or serialized data.
- The original XNB may include `Version=1.0.0.0` and other identity fields. The tool preserves those fields. If runtime binding still fails, inspect the actual assembly identity and update these metadata fields appropriately.
- If content is loaded from a different directory than `Content`, point `-Root` at the actual asset folder.


## Version 2: LZX compressed XNB support

Uses `Compression/LzxDecoder.cs` and `Compression/LzxDecoderStream.cs` from the supplied XnbExtractor project. LZX-compressed XNB files are decoded to an **uncompressed** XNB, then only matching reader names are changed. Other asset payload bytes remain unchanged after decompression. LZ4 XNBs are still skipped. Files without matching readers are not emitted. This may increase file sizes.

Important: use a fresh empty output folder; the tool intentionally refuses to overwrite existing patched files. Run the tool in WhatIf mode first. The repair does not automatically copy assets into Build Manager's deployed game directory. The reader assembly version is preserved; ensure the built assembly identity matches.

The included LZX decoder has its original dual LGPL-2.1 / MS-PL licensing comments; review license obligations before redistribution.
